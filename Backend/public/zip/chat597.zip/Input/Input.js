import React, { ChangeEvent } from "react";
import "./Input.scss";

var inputValue;

const Input = (props) => {
  const [visible, setShow] = React.useState(true);
  return (
    <div className="input">
      <span className="inputLabel">{props.label}</span>

      <div className="inputValue">
        {props.type === "password" &&
          (visible === true ? (
            <span
              className="showHideBtn"
              onClick={() => setShow(!visible)}
              id="visibility"
            >
              Show
            </span>
          ) : (
            <span
              className="showHideBtn"
              onClick={() => setShow(!visible)}
              id="visibility"
            >
              Hide
            </span>
          ))}
        <input
          id={props.color === "#EA4335" ? "inputTagError" : "inputTag"}
          type={visible ? props.type : "text"}
          placeholder={props.placeholder}
          value={inputValue}
          onChange={(e) => props.onChange(e)}
          onKeyPress={props.onKeyPress}
        />
      </div>
    </div>
  );
};

export default Input;
